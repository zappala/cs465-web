# Encrypted Communication

See the assignment page for instructions. This file explains how to run the
server you are given.

## 1. Pick the server for your computer

| Computer                              | Server binary                  |
| ------------------------------------- | ------------------------------ |
| Mac with Apple Silicon (M1 or later)  | `binaries/server-macos-arm64`  |
| Mac with an Intel processor           | `binaries/server-macos-x86_64` |
| Linux, x86-64                         | `binaries/server-linux-x86_64` |
| Linux, ARM64                          | `binaries/server-linux-arm64`  |
| Windows (use WSL)                     | `binaries/server-linux-x86_64` |

Not sure? Run `uname -m`: `arm64` or `aarch64` means ARM; `x86_64` means x86-64.

**On a Mac, run this once first** (from this folder). macOS blocks programs
downloaded from the internet, and without this the server is killed as soon
as it starts, with no error message:

```sh
xattr -d com.apple.quarantine binaries/server-macos-*
```

## 2. Run it

In one terminal, start the server (use your binary from the table):

```sh
./binaries/server-macos-arm64
```

In a second terminal, run your client:

```sh
cargo run
```

The TAs grade your client by running the server with `--grade`, and you can do
the same to check your work. It prints what your client got right and a score
when your client exits:

```sh
./binaries/server-macos-arm64 --grade
```

You need Rust 1.98 or newer (the version the Rust book uses). Run
`rustup update` to get the latest version.
