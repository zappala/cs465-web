// Cracking Password Vaults: see the project page for the full instructions.
//
// 1. Decrypt the practice vault in practice/ with the password you're given.
// 2. Crack the vaults in breach/ using the passwords in breach/passwords.
//
// Run with `cargo run --release`: a debug build is about 50 times slower.

fn main() {
    println!("Practice vault:");
    // TODO

    println!("Breach vaults:");
    // TODO
}
