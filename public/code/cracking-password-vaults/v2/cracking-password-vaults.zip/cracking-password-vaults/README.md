# Cracking Password Vaults

The instructions are on the course website, on the Cracking Password Vaults
(updated) project page.

You need Rust 1.98 or newer (run `rustup update`).

| Path | What |
| --- | --- |
| `practice/vaults` | One vault |
| `practice/passwords` | The password for that vault |
| `breach/vaults` | Vaults from the password manager breach |
| `breach/passwords` | Passwords from a separate breach |
| `Cargo.toml` | The crates you need, at versions that work together |
| `src/main.rs` | Write your cracker here |

Run your code from this folder with

```bash
cargo run --release
```

A release build matters here: each password guess runs 600,000 rounds of
PBKDF2. Cracking all the vaults takes a few seconds in a release build and
about five minutes in a debug build.
